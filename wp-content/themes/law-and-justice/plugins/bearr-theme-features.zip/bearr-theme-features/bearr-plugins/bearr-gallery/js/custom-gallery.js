//Use Strict Mode
(function ($) {
    "use strict";

    //Begin - Window Load
    $(window).load(function () {

        // Gallery Fancybox
        $(".bearr-gallery-item a").simpleLightbox();       

    });

    //End - Use Strict mode
})(jQuery);
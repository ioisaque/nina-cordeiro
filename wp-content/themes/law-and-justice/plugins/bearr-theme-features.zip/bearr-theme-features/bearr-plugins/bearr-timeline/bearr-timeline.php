<?php
/*
Plugin Name: BeaRR: Timeline
Plugin URI: http://themebear.co
Description: Adds timeline Functionality for ThemeBar WordPress Themes.
Author: ThemeBear
Version: 1.0
Author URI: http://themebear.co
*/
/**
 * Advanced Custom Fields Configuration
 *
 *
 * @package bearr
 * 
 */

/*
 * Shortcodes
 */
require ('timeline_shortcodes.php');
/*
 * King Composer
 */
require ('timeline_extend-king-composer.php');
<?php
/*
Plugin Name: BeaRR: Elements
Plugin URI: http://themebear.co
Description: Shortcodes for ThemeBear WordPress Themes.
Author: ThemeBear
Version: 1.0
Author URI: http://themebear.co
*/
/**
 *
 *
 * @package bearr
 * 
 */

/*
 * Shortcodes
 */
require ('elements_shortcodes.php');
/*
 * King Composer
 */
require ('elements_extend-king-composer.php');
<?php
/*
Plugin Name: BeaRR: Wedding Elements
Plugin URI: http://themebear.co
Description: Adds wedding elements shortcodes for ThemeBear WordPress Themes.
Author: ThemeBear
Version: 1.0
Author URI: http://themebear.co
*/
/**
 * Advanced Custom Fields Configuration
 *
 *
 * @package bearr
 * 
 */

/*
 * Shortcodes
 */
require ('wedding-elements_shortcodes.php');
/*
 * King Composer
 */
require ('wedding-elements_extend-king-composer.php');
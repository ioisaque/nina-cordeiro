//Use Strict Mode
(function ($) {
    "use strict";

    //Begin - Window Load
    $(window).load(function () {

        $(".clients-carousel").owlCarousel({
            items: 3,
            nav: false,
            margin: 20
        });

       

    });

    //End - Use Strict mode
})(jQuery);
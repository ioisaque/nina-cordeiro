//Use Strict Mode
(function ($) {
    "use strict";

    //Begin - Window Load
    $(window).load(function () {

        $(".testimonial-carousel").owlCarousel({
            items: 1,
            nav: false,        	
        });

    });

    //End - Use Strict mode
})(jQuery);
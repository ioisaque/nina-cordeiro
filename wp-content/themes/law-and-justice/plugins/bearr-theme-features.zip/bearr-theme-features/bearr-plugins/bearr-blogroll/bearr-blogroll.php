<?php
/*
Plugin Name: BeaRR: Blogroll
Plugin URI: http://themebear.co
Description: Adds blogroll Functionality for ThemeBar WordPress Themes.
Author: ThemeBear
Version: 1.0
Author URI: http://themebear.co
*/
/**
 * Advanced Custom Fields Configuration
 *
 *
 * @package bearr
 * 
 */

/*
 * Shortcodes
 */
require ('blogroll_shortcodes.php');
/*
 * King Composer
 */
require ('blogroll_extend-king-composer.php');
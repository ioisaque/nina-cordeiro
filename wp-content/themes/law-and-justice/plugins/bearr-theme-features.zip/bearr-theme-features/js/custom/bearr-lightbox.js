//Use Strict Mode
(function ($) {
    "use strict";

    //Begin - Window Load
    $(window).load(function () {

        // Gallery Fancybox
        $('.lightbox-image').simpleLightbox();       

    });

    //End - Use Strict mode
})(jQuery);